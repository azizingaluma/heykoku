# Just for You, Koku

Tovuti ya zawadi (faili moja: index.html). Hariri `CONFIG` ndani ya index.html kubadilisha jina, barua, quiz n.k.

## GitHub Pages
1. Tengeneza repo mpya kwenye GitHub, pakia faili zote za folda hii.
2. Settings > Pages > Source: "Deploy from a branch" > Branch: main, folder: / (root) > Save.
3. Subiri dakika 1-2. Anwani: https://JINA-LAKO.github.io/JINA-LA-REPO/
